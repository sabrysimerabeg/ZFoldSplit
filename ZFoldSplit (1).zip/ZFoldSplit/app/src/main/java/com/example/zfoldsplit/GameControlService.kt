package com.example.zfoldsplit

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Rect
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class GameControlService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val wake = Channel<Unit>(Channel.CONFLATED)

    /** Un « doigt virtuel » : slots 0-1 = sticks, slots 2-9 = boutons (id + 2). */
    private class Slot {
        var down = false
        var latched = false // un appui a eu lieu depuis le dernier cycle (tap rapide)
        var dx = 0f
        var dy = 0f
        var stroke: StrokeDescription? = null
        var last: PointF? = null
    }

    private val slots = Array(10) { Slot() }
    private val overlayViews = mutableListOf<View>()

    override fun onServiceConnected() {
        instance = this
        scope.launch { InputBridge.events.collect { handle(it) } }
        scope.launch { gestureLoop() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        hideOverlay()
        instance = null
        scope.cancel()
        super.onDestroy()
    }

    // ---------- Mode « côtés » : barres de touches de chaque côté ----------

    fun showOverlay() {
        if (overlayViews.isNotEmpty()) return
        PadLayout.load(this)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val screenW = wm.currentWindowMetrics.bounds.width()
        val w = (screenW * PadLayout.sideFraction).toInt()

        fun params(gravity: Int) = WindowManager.LayoutParams(
            w,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity }

        val left = SidePanelView(this, true, { hideOverlay() }, { openLauncher() })
        val right = SidePanelView(this, false, { hideOverlay() }, { openLauncher() })
        wm.addView(left, params(Gravity.START or Gravity.TOP))
        wm.addView(right, params(Gravity.END or Gravity.TOP))
        overlayViews.add(left)
        overlayViews.add(right)
    }

    val overlayVisible: Boolean get() = overlayViews.isNotEmpty()

    /** Ouvre le lanceur d'applications (écran du milieu). */
    fun openLauncher() {
        startActivity(
            Intent(this, LauncherActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    fun hideOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayViews.forEach { runCatching { wm.removeView(it) } }
        overlayViews.clear()
    }

    // ---------- Mode écran partagé haut/bas ----------

    /** À appeler après que le jeu a été lancé au premier plan. */
    fun startSplit() {
        scope.launch {
            delay(1200)
            performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
            delay(1000)
            val i = Intent(this@GameControlService, ControllerActivity::class.java)
                .addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT or
                        Intent.FLAG_ACTIVITY_MULTIPLE_TASK
                )
            startActivity(i)
        }
    }

    // ---------- Manette -> gestes ----------

    private fun handle(e: PadEvent) {
        when (e) {
            is PadEvent.Stick -> {
                val s = slots[e.id.coerceIn(0, 1)]
                s.dx = e.dx
                s.dy = e.dy
                if (e.active) {
                    s.down = true
                    s.latched = true
                } else {
                    s.down = false
                }
            }
            is PadEvent.Button -> {
                if (e.id !in 0..7) return
                val s = slots[2 + e.id]
                s.down = e.down
                if (e.down) s.latched = true
            }
        }
        wake.trySend(Unit)
    }

    /**
     * Tous les doigts virtuels sont envoyés dans UN SEUL geste à chaque cycle
     * (un nouveau geste annulerait le précédent), avec des traits « continués ».
     */
    private suspend fun gestureLoop() {
        while (true) {
            if (slots.none { it.down || it.latched || it.stroke != null }) wake.receive()

            val b = gameBounds()
            val r = PadLayout.STICK_RADIUS_FRAC * b.width()
            val builder = GestureDescription.Builder()
            var n = 0

            for (i in slots.indices) {
                val s = slots[i]
                val active = s.down || s.latched
                s.latched = false
                val prev = s.stroke
                if (!active && prev == null) continue

                val base = if (i < 2) PadLayout.sticks[i] else (PadLayout.buttons[i - 2] ?: (0.5f to 0.5f))
                val start: PointF
                val target: PointF
                if (i < 2) {
                    val center = place(b, base.first, base.second, 0f, 0f)
                    start = s.last ?: center
                    target = if (s.down) place(b, base.first, base.second, s.dx * r, s.dy * r) else start
                } else {
                    start = place(b, base.first, base.second, 0f, 0f)
                    target = start
                }

                val path = Path().apply {
                    moveTo(start.x, start.y)
                    if (start.x != target.x || start.y != target.y) lineTo(target.x, target.y)
                }
                val stroke = prev?.continueStroke(path, 0L, STEP_MS, s.down)
                    ?: StrokeDescription(path, 0L, STEP_MS, s.down)
                builder.addStroke(stroke)
                n++

                if (s.down) {
                    s.stroke = stroke
                    s.last = target
                } else {
                    s.stroke = null
                    s.last = null
                }
            }

            if (n == 0) continue
            if (!dispatch(builder.build())) {
                slots.forEach { it.stroke = null; it.last = null }
            }
        }
    }

    /** Position écran d'un contrôle du jeu ; en mode côtés, ramenée dans la zone centrale. */
    private fun place(b: Rect, fx: Float, fy: Float, dxPx: Float, dyPx: Float): PointF {
        val inset = if (overlayViews.isNotEmpty()) PadLayout.sideFraction * b.width() else 0f
        val minX = b.left + inset + 4f
        val maxX = b.right - inset - 4f
        val x = (b.left + fx * b.width() + dxPx).coerceIn(minX, maxX)
        val y = (b.top + fy * b.height() + dyPx).coerceIn(b.top + 4f, b.bottom - 4f)
        return PointF(x, y)
    }

    /** Fenêtre d'application la plus haute qui n'est pas la nôtre = le jeu. */
    private fun gameBounds(): Rect {
        val own = packageName
        val candidates = windows.filter {
            it.type == AccessibilityWindowInfo.TYPE_APPLICATION &&
                it.root?.packageName?.toString() != own
        }
        val top = candidates.minByOrNull { w -> Rect().also { w.getBoundsInScreen(it) }.top }
        val r = Rect()
        if (top != null) {
            top.getBoundsInScreen(r)
        } else {
            val m = resources.displayMetrics
            r.set(0, 0, m.widthPixels, m.heightPixels)
        }
        return r
    }

    private suspend fun dispatch(g: GestureDescription): Boolean =
        suspendCancellableCoroutine { c ->
            val ok = dispatchGesture(
                g,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (c.isActive) c.resume(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (c.isActive) c.resume(false)
                    }
                },
                null
            )
            if (!ok && c.isActive) c.resume(false)
        }

    companion object {
        @Volatile
        var instance: GameControlService? = null
        const val STEP_MS = 60L
    }
}
