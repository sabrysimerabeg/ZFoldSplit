package com.example.zfoldsplit

import android.app.Activity
import androidx.window.layout.FoldingFeature
import androidx.window.layout.WindowInfoTracker
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Émet le pli (charnière) courant, ou null si l'écran est plat / sans pli. */
fun foldingFeatureFlow(activity: Activity): Flow<FoldingFeature?> =
    WindowInfoTracker.getOrCreate(activity)
        .windowLayoutInfo(activity)
        .map { info -> info.displayFeatures.filterIsInstance<FoldingFeature>().firstOrNull() }

fun describeFold(f: FoldingFeature?): String = when {
    f == null -> "Pli : aucun (écran à plat)"
    else -> {
        val state = if (f.state == FoldingFeature.State.HALF_OPENED) "mi-ouvert" else "à plat"
        val orient = if (f.orientation == FoldingFeature.Orientation.HORIZONTAL) "horizontal" else "vertical"
        "Pli : $state, $orient, y=${f.bounds.top}"
    }
}
