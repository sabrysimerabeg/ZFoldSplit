package com.example.zfoldsplit

import android.content.Context
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow

/** Événements émis par la manette vers le service d'accessibilité. */
sealed interface PadEvent {
    /** id : 0 = stick gauche, 1 = stick droit. dx, dy dans [-1, 1]. */
    data class Stick(val dx: Float, val dy: Float, val active: Boolean, val id: Int = 0) : PadEvent

    /** id : 0=A 1=B 2=X 3=Y 4=L1 5=R1 6=L2 7=R2. */
    data class Button(val id: Int, val down: Boolean) : PadEvent
}

/** Pont en mémoire (même processus) entre la manette et le service. */
object InputBridge {
    val events = MutableSharedFlow<PadEvent>(
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    fun send(e: PadEvent) {
        events.tryEmit(e)
    }
}

/**
 * Où les contrôles du JEU sont touchés, en fraction (0..1) de la fenêtre du jeu.
 * En mode « côtés », les points sont ramenés dans la zone centrale (les barres
 * latérales interceptent les touches). À adapter à chaque jeu.
 */
object PadLayout {
    /** Largeur de chaque barre latérale, en fraction de l'écran. */
    var sideFraction = 0.22f
    const val STICK_RADIUS_FRAC = 0.08f

    fun load(ctx: Context) {
        sideFraction = ctx.getSharedPreferences("zfs", Context.MODE_PRIVATE)
            .getFloat("side", 0.22f).coerceIn(0.10f, 0.35f)
    }

    fun save(ctx: Context, f: Float) {
        sideFraction = f
        ctx.getSharedPreferences("zfs", Context.MODE_PRIVATE).edit().putFloat("side", f).apply()
    }

    /** Centres des sticks du jeu : 0 = gauche (déplacement), 1 = droit (caméra). */
    val sticks = listOf(0.30f to 0.72f, 0.70f to 0.72f)

    val buttons: Map<Int, Pair<Float, Float>> = mapOf(
        0 to (0.72f to 0.60f), // A
        1 to (0.77f to 0.50f), // B
        2 to (0.67f to 0.50f), // X
        3 to (0.72f to 0.40f), // Y
        4 to (0.28f to 0.25f), // L1
        5 to (0.72f to 0.25f), // R1
        6 to (0.28f to 0.40f), // L2
        7 to (0.72f to 0.32f)  // R2
    )
}
