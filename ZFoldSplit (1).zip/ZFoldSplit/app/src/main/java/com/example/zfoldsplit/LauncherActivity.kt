package com.example.zfoldsplit

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

/** Écran du milieu : grille des applications installées (YouTube, jeux, etc.). */
class LauncherActivity : ComponentActivity() {

    private class AppItem(val label: String, val pkg: String, val icon: Drawable)

    private var all: List<AppItem> = emptyList()
    private var shown: List<AppItem> = emptyList()
    private lateinit var adapter: BaseAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = pm.queryIntentActivities(query, PackageManager.MATCH_ALL)
            .map { it.activityInfo }
            .filter { it.packageName != packageName }
            .distinctBy { it.packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.packageName, it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
        shown = all

        val dp = resources.displayMetrics.density
        // Laisse la place aux barres de touches quand elles sont affichées
        PadLayout.load(this)
        val side = if (GameControlService.instance?.overlayVisible == true)
            (resources.displayMetrics.widthPixels * PadLayout.sideFraction).toInt() else 0
        val pad = (16 * dp).toInt()

        val search = EditText(this).apply {
            hint = "Rechercher une application"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setSingleLine()
        }

        adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(position: Int): Any = shown[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val item = shown[position]
                val row = LinearLayout(this@LauncherActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(0, pad / 2, 0, pad / 2)
                }
                row.addView(ImageView(this@LauncherActivity).apply {
                    setImageDrawable(item.icon)
                    layoutParams = LinearLayout.LayoutParams((52 * dp).toInt(), (52 * dp).toInt())
                })
                row.addView(TextView(this@LauncherActivity).apply {
                    text = item.label
                    setTextColor(Color.WHITE)
                    textSize = 12f
                    gravity = Gravity.CENTER
                    maxLines = 2
                })
                return row
            }
        }

        val grid = GridView(this).apply {
            numColumns = 4
            adapter = this@LauncherActivity.adapter
            setOnItemClickListener { _, _, position, _ ->
                val intent = packageManager.getLaunchIntentForPackage(shown[position].pkg)
                if (intent != null) startActivity(intent)
                else Toast.makeText(this@LauncherActivity, "Impossible de lancer", Toast.LENGTH_SHORT).show()
            }
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) = Unit
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim()?.lowercase().orEmpty()
                shown = if (q.isEmpty()) all else all.filter { it.label.lowercase().contains(q) }
                adapter.notifyDataSetChanged()
            }
        })

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(18, 18, 24))
            setPadding(side + pad, pad * 2, side + pad, pad)
            addView(search)
            addView(grid, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        })
    }
}
