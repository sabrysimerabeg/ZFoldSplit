package com.example.zfoldsplit

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var pkg: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PadLayout.load(this)

        status = TextView(this)
        pkg = EditText(this).apply {
            hint = "Package d'une appli à lancer directement (facultatif)"
        }

        val step1 = Button(this).apply {
            text = "1. Activer le service d'accessibilité"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val sides = Button(this).apply {
            text = "2. Mode côtés : appli au milieu + manette de chaque côté"
            setOnClickListener { startSides() }
        }
        val launcher = Button(this).apply {
            text = "Ouvrir le lanceur d'applications"
            setOnClickListener { startActivity(Intent(this@MainActivity, LauncherActivity::class.java)) }
        }
        val split = Button(this).apply {
            text = "Mode haut/bas : appli en haut + manette en bas"
            setOnClickListener { startSplit() }
        }
        val hide = Button(this).apply {
            text = "Masquer les touches latérales"
            setOnClickListener { GameControlService.instance?.hideOverlay() }
        }

        val sideLabel = TextView(this).apply {
            text = "Largeur des barres : ${(PadLayout.sideFraction * 100).toInt()} %"
        }
        val sideBar = SeekBar(this).apply {
            max = 25 // 10 % .. 35 %
            progress = ((PadLayout.sideFraction * 100).toInt() - 10).coerceIn(0, 25)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val f = (p + 10) / 100f
                    PadLayout.save(this@MainActivity, f)
                    sideLabel.text = "Largeur des barres : ${p + 10} %"
                }

                override fun onStartTrackingTouch(sb: SeekBar?) = Unit
                override fun onStopTrackingTouch(sb: SeekBar?) = Unit
            })
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            listOf(status, pkg, step1, sides, launcher, split, hide, sideLabel, sideBar)
                .forEach { addView(it) }
        })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (GameControlService.instance != null)
            "Service d'accessibilité : actif ✔"
        else "Service d'accessibilité : inactif (étape 1)"
    }

    private fun service(): GameControlService? {
        val s = GameControlService.instance
        if (s == null) {
            Toast.makeText(this, "Active d'abord le service d'accessibilité", Toast.LENGTH_LONG).show()
        }
        return s
    }

    private fun targetIntent(): Intent? {
        val p = pkg.text.toString().trim()
        if (p.isEmpty()) return Intent(this, LauncherActivity::class.java)
        val i = packageManager.getLaunchIntentForPackage(p)
        if (i == null) Toast.makeText(this, "Package introuvable", Toast.LENGTH_LONG).show()
        return i
    }

    private fun startSides() {
        val s = service() ?: return
        val i = targetIntent() ?: return
        s.showOverlay()
        startActivity(i)
    }

    private fun startSplit() {
        val s = service() ?: return
        val p = pkg.text.toString().trim()
        val i = packageManager.getLaunchIntentForPackage(p)
        if (i == null) {
            Toast.makeText(this, "Saisis le package de l'appli", Toast.LENGTH_LONG).show()
            return
        }
        startActivity(i)
        s.startSplit()
    }
}
