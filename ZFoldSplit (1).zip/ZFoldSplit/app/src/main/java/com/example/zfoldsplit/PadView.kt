package com.example.zfoldsplit

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/** Manette virtuelle multi-touch : un stick à gauche, 4 boutons (A/B/X/Y) à droite. */
class PadView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labels = listOf("A", "B", "X", "Y")
    private val btnPointers = mutableMapOf<Int, Int>() // pointerId -> bouton
    private var stickPointer = -1
    private var knobDx = 0f
    private var knobDy = 0f

    init { setBackgroundColor(Color.rgb(18, 18, 24)) }

    private val stickR get() = min(width, height) * 0.28f
    private val btnOffset get() = min(width, height) * 0.22f
    private val btnR get() = btnOffset * 0.45f
    private fun stickCenter() = PointF(width * 0.22f, height * 0.55f)
    private fun btnCenter(i: Int): PointF {
        val c = PointF(width * 0.78f, height * 0.55f)
        val d = btnOffset
        return when (i) {
            0 -> PointF(c.x, c.y + d)
            1 -> PointF(c.x + d, c.y)
            2 -> PointF(c.x - d, c.y)
            else -> PointF(c.x, c.y - d)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> down(e, e.actionIndex)
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) {
                if (e.getPointerId(i) == stickPointer) moveStick(e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> {
                btnPointers.keys.toList().forEach { up(it) }
                up(stickPointer)
            }
        }
        invalidate()
        return true
    }

    private fun down(e: MotionEvent, i: Int) {
        val id = e.getPointerId(i)
        val x = e.getX(i)
        val y = e.getY(i)
        val btn = (0..3).firstOrNull { hypot(x - btnCenter(it).x, y - btnCenter(it).y) <= btnR }
        if (btn != null) {
            btnPointers[id] = btn
            InputBridge.send(PadEvent.Button(btn, true))
        } else if (stickPointer == -1 && x < width / 2f) {
            stickPointer = id
            moveStick(x, y)
        }
    }

    private fun moveStick(x: Float, y: Float) {
        val c = stickCenter()
        var dx = (x - c.x) / stickR
        var dy = (y - c.y) / stickR
        val len = hypot(dx, dy)
        if (len > 1f) { dx /= len; dy /= len }
        knobDx = dx; knobDy = dy
        InputBridge.send(PadEvent.Stick(dx, dy, true))
    }

    private fun up(id: Int) {
        if (id == -1) return
        if (id == stickPointer) {
            stickPointer = -1
            knobDx = 0f; knobDy = 0f
            InputBridge.send(PadEvent.Stick(0f, 0f, false))
        } else {
            btnPointers.remove(id)?.let { InputBridge.send(PadEvent.Button(it, false)) }
        }
    }

    override fun onDraw(canvas: Canvas) {
        val c = stickCenter()
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(70, 255, 255, 255)
        canvas.drawCircle(c.x, c.y, stickR, paint)
        paint.color = Color.argb(180, 120, 180, 255)
        canvas.drawCircle(c.x + knobDx * stickR, c.y + knobDy * stickR, stickR * 0.35f, paint)

        paint.textAlign = Paint.Align.CENTER
        paint.textSize = btnR * 0.9f
        for (i in 0..3) {
            val b = btnCenter(i)
            val pressed = btnPointers.containsValue(i)
            paint.color = if (pressed) Color.argb(220, 255, 200, 80) else Color.argb(110, 255, 255, 255)
            canvas.drawCircle(b.x, b.y, btnR, paint)
            paint.color = Color.BLACK
            canvas.drawText(labels[i], b.x, b.y + btnR * 0.3f, paint)
        }
    }
}
