package com.example.zfoldsplit

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/**
 * Barre latérale de la manette.
 * Gauche : stick gauche + L1/L2 + accueil (lanceur) + fermeture.
 * Droite : stick droit + A/B/X/Y + R1/R2.
 */
class SidePanelView(
    context: Context,
    private val isLeft: Boolean,
    private val onClose: () -> Unit,
    private val onHome: () -> Unit = {}
) : View(context) {

    private class Btn(val id: Int, val label: String, val cx: Float, val cy: Float)
    private class Stk(val id: Int, val cx: Float, val cy: Float, val r: Float)
    private object Close
    private object Home

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val buttons = ArrayList<Btn>()
    private var stick: Stk? = null
    private var br = 0f
    private var closeX = 0f
    private var homeX = 0f
    private var topY = 0f
    private var topR = 0f
    private val held = HashMap<Int, Any>() // pointerId -> Btn | Stk | Close | Home
    private val pressed = HashSet<Int>()
    private var knobDx = 0f
    private var knobDy = 0f

    init { setBackgroundColor(Color.argb(225, 12, 12, 18)) }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        br = 0.17f * wf
        topR = 0.09f * wf
        closeX = 0.16f * wf
        homeX = 0.42f * wf
        topY = 0.05f * hf
        buttons.clear()
        if (isLeft) {
            buttons.add(Btn(6, "L2", 0.5f * wf, 0.15f * hf))
            buttons.add(Btn(4, "L1", 0.5f * wf, 0.15f * hf + 2.5f * br))
            stick = Stk(0, 0.5f * wf, 0.74f * hf, 0.34f * wf)
        } else {
            buttons.add(Btn(7, "R2", 0.5f * wf, 0.15f * hf))
            buttons.add(Btn(5, "R1", 0.5f * wf, 0.15f * hf + 2.5f * br))
            val cx = 0.5f * wf
            val cy = 0.45f * hf
            val d = 0.30f * wf
            buttons.add(Btn(0, "A", cx, cy + d))
            buttons.add(Btn(1, "B", cx + d, cy))
            buttons.add(Btn(2, "X", cx - d, cy))
            buttons.add(Btn(3, "Y", cx, cy - d))
            stick = Stk(1, 0.5f * wf, 0.82f * hf, 0.32f * wf)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) {
                val t = held[e.getPointerId(i)]
                if (t is Stk) moveStick(t, e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> held.keys.toList().forEach { up(it) }
        }
        invalidate()
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        if (isLeft && hypot(x - closeX, y - topY) <= topR * 1.6f) {
            held[id] = Close
            return
        }
        if (isLeft && hypot(x - homeX, y - topY) <= topR * 1.6f) {
            held[id] = Home
            return
        }
        val b = buttons.firstOrNull { hypot(x - it.cx, y - it.cy) <= br * 1.2f }
        if (b != null) {
            held[id] = b
            pressed.add(b.id)
            InputBridge.send(PadEvent.Button(b.id, true))
            return
        }
        val s = stick
        if (s != null && hypot(x - s.cx, y - s.cy) <= s.r * 1.5f && held.values.none { it is Stk }) {
            held[id] = s
            moveStick(s, x, y)
        }
    }

    private fun moveStick(s: Stk, x: Float, y: Float) {
        var dx = (x - s.cx) / s.r
        var dy = (y - s.cy) / s.r
        val len = hypot(dx, dy)
        if (len > 1f) { dx /= len; dy /= len }
        knobDx = dx
        knobDy = dy
        InputBridge.send(PadEvent.Stick(dx, dy, true, s.id))
    }

    private fun up(id: Int) {
        val t = held.remove(id)
        if (t is Btn) {
            pressed.remove(t.id)
            InputBridge.send(PadEvent.Button(t.id, false))
        } else if (t is Stk) {
            knobDx = 0f
            knobDy = 0f
            InputBridge.send(PadEvent.Stick(0f, 0f, false, t.id))
        } else if (t === Close) {
            post { onClose() }
        } else if (t === Home) {
            post { onHome() }
        }
    }

    override fun onDraw(canvas: Canvas) {
        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER

        if (isLeft) {
            // Fermer
            paint.color = Color.argb(170, 255, 255, 255)
            canvas.drawCircle(closeX, topY, topR, paint)
            paint.color = Color.BLACK
            paint.textSize = topR * 1.1f
            canvas.drawText("X", closeX, topY + topR * 0.4f, paint)

            // Accueil (maison)
            paint.color = Color.argb(170, 255, 255, 255)
            canvas.drawCircle(homeX, topY, topR, paint)
            paint.color = Color.BLACK
            val r = topR
            val house = Path().apply {
                moveTo(homeX, topY - 0.55f * r)
                lineTo(homeX + 0.6f * r, topY)
                lineTo(homeX + 0.4f * r, topY)
                lineTo(homeX + 0.4f * r, topY + 0.5f * r)
                lineTo(homeX - 0.4f * r, topY + 0.5f * r)
                lineTo(homeX - 0.4f * r, topY)
                lineTo(homeX - 0.6f * r, topY)
                close()
            }
            canvas.drawPath(house, paint)
        }

        stick?.let { s ->
            paint.color = Color.argb(70, 255, 255, 255)
            canvas.drawCircle(s.cx, s.cy, s.r, paint)
            paint.color = Color.argb(190, 120, 180, 255)
            canvas.drawCircle(s.cx + knobDx * s.r, s.cy + knobDy * s.r, s.r * 0.38f, paint)
        }

        paint.textSize = br * 0.8f
        for (b in buttons) {
            val on = pressed.contains(b.id)
            paint.color = if (on) Color.argb(230, 255, 200, 80) else Color.argb(120, 255, 255, 255)
            canvas.drawCircle(b.cx, b.cy, br, paint)
            paint.color = Color.BLACK
            canvas.drawText(b.label, b.cx, b.cy + br * 0.28f, paint)
        }
    }
}
