# ZFoldSplit

Squelette Android (Kotlin) : jeu en haut de l'écran interne d'un Galaxy Z Fold, manette virtuelle en bas.

## Ouvrir et lancer
1. Ouvrir le dossier dans Android Studio (Ladybug ou plus récent) ; il génère le wrapper Gradle.
2. Installer sur le Z Fold (minSdk 30, One UI récent).
3. Appli : activer le service d'accessibilité → saisir le package du jeu → « Lancer le jeu + écran partagé + manette ».

## Structure
- `HingeTracker.kt` : détection du pli via Jetpack WindowManager (`FoldingFeature`).
- `ControllerActivity.kt` + `PadView.kt` : panneau du bas, stick + boutons A/B/X/Y multi-touch.
- `InputBridge.kt` : événements manette + `PadLayout` (positions des contrôles dans le jeu, en fractions).
- `GameControlService.kt` : service d'accessibilité ; bascule l'écran partagé, repère la fenêtre du jeu, traduit stick/boutons en gestes (`dispatchGesture`).

## À vérifier sur l'appareil (non testé)
- Le jeu doit être redimensionnable, sinon le split est refusé (Good Lock MultiStar / option développeur « forcer le redimensionnement »).
- Lancement de `ControllerActivity` depuis le service en `LAUNCH_ADJACENT` : si One UI le bloque, choisir l'appli manuellement dans la liste du split.
- Gestes simultanés (stick + bouton) : selon la version d'Android, un nouveau `dispatchGesture` peut annuler le précédent.
- Ajuster `PadLayout` par jeu ; prochaine étape : éditeur de manette (JSON) et prise en compte du pli pour placer la frontière.
- Distribution : le Play Store restreint l'usage non-assistance de l'accessibilité → APK direct.

## Tout faire depuis un téléphone Android (sans ordinateur)
1. Crée un compte gratuit sur github.com, puis un dépôt vide (nom : ZFoldSplit).
2. Dézippe ce projet sur le téléphone, puis dans le dépôt : « Add file » > « Upload files » et envoie tout le contenu (dossier `.github` compris : s'il n'apparaît pas, active « fichiers cachés » dans ton gestionnaire de fichiers).
3. Onglet « Actions » : le workflow « Build APK » se lance seul (≈ 5 min). Ouvre l'exécution terminée, section « Artifacts », télécharge `ZFoldSplit-apk` (un zip contenant `app-debug.apk`).
4. Extrais l'APK et installe-le (autorise « sources inconnues » pour ton navigateur ou gestionnaire de fichiers).
5. Android 13+ : si le service d'accessibilité est grisé, va dans Paramètres > Applications > ZFoldSplit > ⋮ > « Autoriser les paramètres restreints », puis active le service.

Alternative 100 % locale : l'application AndroidIDE (open source, hors Play Store) ouvre et compile ce projet sur le téléphone.
