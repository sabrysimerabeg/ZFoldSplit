package com.example.zfoldsplit

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PointF
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class GameControlService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    @Volatile
    private var stick = PadEvent.Stick(0f, 0f, false)
    private var stickJob: Job? = null

    override fun onServiceConnected() {
        instance = this
        scope.launch { InputBridge.events.collect { handle(it) } }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        instance = null
        scope.cancel()
        super.onDestroy()
    }

    // ---------- Écran partagé ----------

    /** À appeler après que le jeu a été lancé au premier plan. */
    fun startSplit() {
        scope.launch {
            delay(1200)
            performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
            delay(1000)
            // Ouvre la manette dans le panneau adjacent (le jeu reste en haut).
            val i = Intent(this@GameControlService, ControllerActivity::class.java)
                .addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT or
                        Intent.FLAG_ACTIVITY_MULTIPLE_TASK
                )
            startActivity(i)
        }
    }

    // ---------- Traduction manette -> gestes ----------

    private fun handle(e: PadEvent) {
        when (e) {
            is PadEvent.Stick -> {
                stick = e
                if (e.active && stickJob?.isActive != true) {
                    stickJob = scope.launch { runStick() }
                }
            }
            is PadEvent.Button -> if (e.down) {
                PadLayout.buttons[e.id]?.let { tap(toScreen(gameBounds(), it)) }
            }
        }
    }

    /** Fenêtre d'application la plus haute qui n'est pas la nôtre = le jeu. */
    private fun gameBounds(): Rect {
        val own = packageName
        val candidates = windows.filter {
            it.type == AccessibilityWindowInfo.TYPE_APPLICATION &&
                it.root?.packageName?.toString() != own
        }
        val top = candidates.minByOrNull { w -> Rect().also { w.getBoundsInScreen(it) }.top }
        val r = Rect()
        if (top != null) top.getBoundsInScreen(r)
        else resources.displayMetrics.let { r.set(0, 0, it.widthPixels, it.heightPixels / 2) }
        return r
    }

    private fun toScreen(b: Rect, frac: Pair<Float, Float>) =
        PointF(b.left + frac.first * b.width(), b.top + frac.second * b.height())

    private fun tap(p: PointF) {
        val path = Path().apply { moveTo(p.x, p.y) }
        val g = GestureDescription.Builder().addStroke(StrokeDescription(path, 0, 40)).build()
        dispatchGesture(g, null, null)
    }

    /** Joystick : un doigt virtuel posé au centre, déplacé par traits successifs (continueStroke). */
    private suspend fun runStick() {
        val b = gameBounds()
        val center = toScreen(b, PadLayout.stickCenter)
        val radius = PadLayout.STICK_RADIUS_FRAC * b.width()
        var last = center
        var prev: StrokeDescription? = null
        while (true) {
            val s = stick
            val target = if (s.active) PointF(center.x + s.dx * radius, center.y + s.dy * radius) else last
            val path = Path().apply { moveTo(last.x, last.y); lineTo(target.x, target.y) }
            val st = prev?.continueStroke(path, 0, STEP_MS, s.active)
                ?: StrokeDescription(path, 0, STEP_MS, s.active)
            if (!dispatch(st)) return
            prev = st
            last = target
            if (!s.active) return
        }
    }

    private suspend fun dispatch(s: StrokeDescription): Boolean =
        suspendCancellableCoroutine { c ->
            val ok = dispatchGesture(
                GestureDescription.Builder().addStroke(s).build(),
                object : GestureResultCallback() {
                    override fun onCompleted(g: GestureDescription?) { if (c.isActive) c.resume(true) }
                    override fun onCancelled(g: GestureDescription?) { if (c.isActive) c.resume(false) }
                },
                null
            )
            if (!ok && c.isActive) c.resume(false)
        }

    companion object {
        @Volatile
        var instance: GameControlService? = null
        const val STEP_MS = 60L
    }
}
