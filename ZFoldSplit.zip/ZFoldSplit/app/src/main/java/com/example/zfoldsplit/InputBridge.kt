package com.example.zfoldsplit

import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow

/** Événements émis par la manette (activité du bas) vers le service d'accessibilité. */
sealed interface PadEvent {
    /** dx, dy dans [-1, 1] ; active=false => stick relâché. */
    data class Stick(val dx: Float, val dy: Float, val active: Boolean) : PadEvent

    /** id : 0=A (bas), 1=B (droite), 2=X (gauche), 3=Y (haut). */
    data class Button(val id: Int, val down: Boolean) : PadEvent
}

/** Pont en mémoire (même processus) entre la manette et le service. */
object InputBridge {
    val events = MutableSharedFlow<PadEvent>(
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    fun send(e: PadEvent) {
        events.tryEmit(e)
    }
}

/**
 * Positions des contrôles DANS le jeu, en fraction (0..1) de la fenêtre du jeu.
 * À adapter à chaque jeu (plus tard : éditeur + sauvegarde JSON).
 */
object PadLayout {
    val stickCenter = 0.18f to 0.70f
    const val STICK_RADIUS_FRAC = 0.10f // fraction de la largeur de la fenêtre du jeu

    val buttons: Map<Int, Pair<Float, Float>> = mapOf(
        0 to (0.85f to 0.75f), // A
        1 to (0.92f to 0.60f), // B
        2 to (0.78f to 0.60f), // X
        3 to (0.85f to 0.45f)  // Y
    )
}
