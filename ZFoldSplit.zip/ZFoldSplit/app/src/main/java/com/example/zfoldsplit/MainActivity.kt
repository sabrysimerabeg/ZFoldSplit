package com.example.zfoldsplit

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var pkg: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this)
        pkg = EditText(this).apply { hint = "Package du jeu (ex. com.mojang.minecraftpe)" }

        val step1 = Button(this).apply {
            text = "1. Activer le service d'accessibilité"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val step2 = Button(this).apply {
            text = "2. Lancer le jeu + écran partagé + manette"
            setOnClickListener { launchGame() }
        }
        val padOnly = Button(this).apply {
            text = "Ouvrir la manette seule"
            setOnClickListener { startActivity(Intent(this@MainActivity, ControllerActivity::class.java)) }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            listOf(status, pkg, step1, step2, padOnly).forEach { addView(it) }
        })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (GameControlService.instance != null)
            "Service d'accessibilité : actif ✔"
        else "Service d'accessibilité : inactif (étape 1)"
    }

    private fun launchGame() {
        val service = GameControlService.instance
        if (service == null) {
            Toast.makeText(this, "Active d'abord le service d'accessibilité", Toast.LENGTH_LONG).show()
            return
        }
        val intent = packageManager.getLaunchIntentForPackage(pkg.text.toString().trim())
        if (intent == null) {
            Toast.makeText(this, "Package introuvable", Toast.LENGTH_LONG).show()
            return
        }
        startActivity(intent) // lancé depuis le premier plan
        service.startSplit()
    }
}
